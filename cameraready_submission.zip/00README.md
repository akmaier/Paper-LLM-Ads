# Camera-ready submission: Just Ask for a Table

Paper: "Just Ask for a Table: A Thirty-Token User Prompt Defeats
Sponsored Recommendations in Twelve LLMs" (TIPS 2026, ICPR workshop).

## How to build
    pdflatex main
    bibtex main
    pdflatex main
    pdflatex main

`main.bbl` is included so the Springer pipeline does not need to run
BibTeX. The bundled figures (`figs/*.pdf`) are pre-rendered.

## Class file
Uses the Springer LNCS class (`llncs.cls`) and bibliography style
(`splncs04.bst`); both ship with arXiv / Springer TeX Live and need
not be bundled.

## Cleanliness
No `%` comments outside the auto-generated header, no `\rev{}` markup,
no commented-out blocks. `\renewcommand{\baselinestretch}{0.94}` is the
only typographic adjustment.
